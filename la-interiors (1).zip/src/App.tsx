/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, useScroll, useSpring, AnimatePresence } from "motion/react";
import { 
  Menu, X, ArrowRight, Instagram, Facebook, Youtube, 
  MapPin, Phone, Mail, Award, ShieldCheck, Layout, 
  Calculator, Quote, Star, ArrowUpRight, Search, ChevronLeft,
  ChevronDown
} from "lucide-react";
import { useState, useEffect } from "react";

const IMAGES = {
  logo: "https://content3.jdmagicbox.com/comp/faridabad/u2/0129px129.x129.210419163613.m6u2/catalogue/la-interiors-sector-81-faridabad-interior-designers-h3q3e5v3w3.jpg",
  hero: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1920&q=80",
  kitchen: "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=800&q=80",
  living: "https://images.unsplash.com/photo-1616489953149-80880004f164?auto=format&fit=crop&w=800&q=80",
  bedroom: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80",
  office: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=800&q=80",
  renovation: "https://images.unsplash.com/photo-1503387762-592dee58c460?auto=format&fit=crop&w=800&q=80",
  portfolio1: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80",
  portfolio2: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=800&q=80",
  portfolio3: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=800&q=80",
  portfolio4: "https://images.unsplash.com/photo-1600121848594-d8644e57abab?auto=format&fit=crop&w=800&q=80",
};

const SERVICES_DATA = [
  { 
    id: "residential",
    title: "Residential Interior", 
    img: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80", 
    desc: "Bespoke home interiors that blend luxury with daily functionality.",
    details: "We transform houses into homes that reflect the people who live in them. Our residential team specializes in creating high-end, functional spaces that balance contemporary aesthetics with the warmth of a personal retreat. From wall treatments to custom furniture, we handle every detail of your sanctuary.",
    features: ["Space Optimization", "Color Consultation", "Custom Woodwork", "Lighting Layouts"]
  },
  { 
    id: "office",
    title: "Office Interior", 
    img: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=80", 
    desc: "Professional workspaces designed to boost productivity and brand image.",
    details: "Modern business requires a workspace that inspires. Our office interiors focus on 'Work-Life Harmony'—creating ergonomic, collaborative spaces that enhance employee focus and impress stakeholders. We integrate smart technology with architectural design to build offices that mean business.",
    features: ["Ergonomic Design", "Acoustic Solutions", "Collaborative Zones", "Brand Integration"]
  },
  { 
    id: "kitchen",
    title: "Kitchen Interior", 
    img: "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1200&q=80", 
    desc: "Modern modular kitchen solutions with optimized space and ergonomics.",
    details: "The kitchen is the heart of the home. Our modular kitchen designs prioritize the 'Golden Triangle'—efficient workflow between the hob, sink, and refrigerator. Using water-resistant materials and premium hardware, we build culinary spaces that are as durable as they are beautiful.",
    features: ["Modular Cabinets", "Anti-Scratch Surfaces", "Smart Storage", "Ventilation Design"]
  },
  { 
    id: "bedroom",
    title: "Bedroom Interior", 
    img: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80", 
    desc: "Sleek and tranquil bedroom designs for the ultimate restorative retreat.",
    details: "Your bedroom should be your sanctuary. We specialize in minimalist, calming designs that eliminate clutter and foster deep rest. Using soft fabrics, architectural headboards, and circadian lighting, we create a private retreat tailored to your sleep quality and morning ritual.",
    features: ["Mood Lighting", "Textile Selection", "Custom Headboards", "Modular Wardrobes"]
  },
  { 
    id: "living",
    title: "Living Room Design", 
    img: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80", 
    desc: "Elegant and welcoming congregating spaces for family and guests.",
    details: "The living room sets the tone for your entire home. Our approach to living room design focuses on hierarchy—creating striking focal points (like custom media units or fireplaces) while ensuring the space remains inviting for large gatherings and quiet family evenings alike.",
    features: ["Focal Wall Design", "Furniture Curation", "Display Units", "Art Integration"]
  },
  { 
    id: "bathroom",
    title: "Bathroom Interior", 
    img: "https://images.unsplash.com/photo-1600121848594-d8644e57abab?auto=format&fit=crop&w=1200&q=80", 
    desc: "Sophisticated bathroom layouts with premium finishes and fixtures.",
    details: "Transform a functional space into a spa-like experience. We utilize premium stonework, moisture-resistant cabinetry, and high-end fixtures to create bathrooms that feel luxurious. Our focus is on plumbing precision combined with high-impact architectural lighting.",
    features: ["Premium Stonework", "Waterproofing Experts", "Concealed Fixtures", "Spa-like Ambiance"]
  }
];

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [selectedService, setSelectedService] = useState<typeof SERVICES_DATA[0] | null>(null);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    projectType: "Full Home Design",
    message: ""
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleEnquiry = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // We'll wait 1.5 seconds for the animation to feel solid before opening Gmail
    setTimeout(() => {
      const subject = encodeURIComponent("Enquiry for Interior Design Services");
      const body = encodeURIComponent(
`Dear LA Interiors Team,

I am writing to express my interest in your interior design services and would like to request a personal estimate for my project. Below are the details as requested:

Personal Estimate

FULL NAME: ${formData.fullName}
PHONE NUMBER: ${formData.phone}
PROJECT TYPE: ${formData.projectType}

BRIEF MESSAGE: ${formData.message}

Thank you for your time and consideration. I look forward to hearing from you soon to discuss the next steps.

Sincerely,
${formData.fullName}`
      );

      // Link to Gmail web-app compose view
      const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=info@lainteriors.in&su=${subject}&body=${body}`;
      
      // Open in a NEW TAB to avoid iframe "refused to connect" errors
      window.open(gmailUrl, '_blank', 'noopener,noreferrer');
      
      setIsSubmitting(false);
      setShowSuccess(true);
      
      // We don't reset form immediately so the backup link can use the data if needed
    }, 1500);
  };

  const scrollToContactWithService = (service: string) => {
    setSelectedService(null);
    setFormData(prev => ({ ...prev, projectType: service }));
    setTimeout(() => {
      const contactSection = document.getElementById('about');
      if (contactSection) {
        contactSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setSelectedService(null);
    setTimeout(() => {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen bg-brand-sand selection:bg-brand-cyan/20">
      {/* Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-brand-cyan origin-left z-[100]"
        style={{ scaleX }}
      />

      <AnimatePresence mode="wait">
        {!selectedService ? (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* Navigation */}
            <nav 
              className={`fixed top-0 w-full z-50 transition-all duration-500 ${
                isScrolled ? "py-4 glass-nav" : "py-6 bg-transparent"
              }`}
            >
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
          <div 
            onClick={() => {
              setSelectedService(null);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-3 group cursor-pointer"
          >
            <img 
              src={IMAGES.logo} 
              alt="LA Interiors" 
              className="h-12 md:h-16 w-auto transition-all duration-500"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                e.currentTarget.parentElement?.querySelector('.logo-fallback')?.classList.remove('hidden');
              }}
              referrerPolicy="no-referrer"
            />
            <div className="logo-fallback hidden flex items-center gap-2">
              <div className="w-8 h-8 bg-brand-cyan flex items-center justify-center text-white font-serif font-bold text-lg">LA</div>
              <span className={`font-serif text-xl font-bold tracking-tight ${isScrolled ? "text-slate-800" : "text-white italic"}`}>INTERIORS</span>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-8">
            {["Services", "Projects", "How it Works", "About"].map((item) => (
              <motion.button 
                key={item} 
                onClick={() => scrollToSection(item.toLowerCase().replace(/\s/g, '-'))}
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className="font-sans text-sm font-medium tracking-wide text-slate-600 hover:text-brand-cyan hover-underline transition-colors uppercase cursor-pointer relative"
              >
                {item}
              </motion.button>
            ))}
            <motion.button 
              onClick={() => scrollToSection('about')}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-brand-orange text-white px-6 py-2.5 text-sm font-semibold hover:bg-brand-orange/90 transition-all shadow-lg hover:shadow-brand-orange/20 uppercase tracking-wider"
            >
              Get Quote
            </motion.button>
          </div>

          <button className="lg:hidden text-slate-800">
            <Menu size={28} />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative h-screen flex items-center justify-center overflow-hidden bg-slate-900">
        <motion.img 
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 2, ease: "easeOut" }}
          src={IMAGES.hero} 
          alt="Luxury Interior" 
          className="absolute inset-0 w-full h-full object-cover opacity-60"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/40 via-transparent to-slate-900/60" />
        
        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="bg-white/95 backdrop-blur-md p-10 md:p-20 border-t-8 border-brand-cyan shadow-2xl"
          >
            <p className="font-sans text-xs font-bold text-brand-cyan tracking-[0.3em] uppercase mb-6">
              Transforming Spaces · Elevating Lives
            </p>
            <h1 className="text-4xl md:text-7xl mb-8 leading-[1.2] text-slate-900 font-extrabold uppercase tracking-tight">
              Best Interior Designers <br />
              <span className="text-brand-cyan">In Faridabad</span>
            </h1>
            <p className="text-slate-600 text-lg md:text-xl max-w-3xl mx-auto mb-10 leading-relaxed font-medium">
              Expert interior designers or decorators in Faridabad and Delhi NCR. Our experts will transform your space into a stunning and functional living area.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <button 
                onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-brand-cyan text-white px-10 py-5 font-bold hover:bg-brand-teal transition-all flex items-center justify-center gap-2 group shadow-xl hover:shadow-brand-cyan/20 uppercase tracking-widest text-sm"
              >
                View Portfolio <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <motion.a 
                href="https://wa.me/919873280202?text=Hi!%20I%20visited%20your%20website%20and%20I%27m%20interested%20in%20your%20interior%20design%20services.%20Can%20we%20connect?"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-white text-slate-900 border-2 border-slate-200 px-10 py-5 font-bold hover:bg-slate-50 transition-all shadow-lg uppercase tracking-widest text-sm inline-block"
              >
                Contact Us Now
              </motion.a>
            </div>
          </motion.div>
        </div>
      </header>

      {/* Features Strip */}
      <section className="bg-brand-cyan py-12 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-2 lg:grid-cols-4 gap-8 text-white">
          {[
            { icon: <Award />, label: "Expert Designers\n& Decorators" },
            { icon: <ShieldCheck />, label: "Stunning &\nFunctional Spaces" },
            { icon: <Layout />, label: "Faridabad &\nDelhi NCR focus" },
            { icon: <Calculator />, label: "Request A\nFree Estimate" }
          ].map((feature, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center gap-4"
            >
              <div className="text-white/80">{feature.icon}</div>
              <p className="text-[11px] md:text-xs font-bold uppercase tracking-[0.15em] leading-snug whitespace-pre-line">
                {feature.label}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* What We Do - Services */}
      <section id="services" className="section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <motion.div 
              initial={{ width: 0 }}
              whileInView={{ width: 48 }}
              className="h-1 bg-brand-cyan mb-6"
            />
            <h2 className="text-4xl md:text-5xl mb-4 uppercase font-extrabold tracking-tight">What We Do</h2>
            <p className="text-slate-500 max-w-2xl text-lg font-medium leading-relaxed">
              We offer comprehensive interior decorating services in Faridabad, creating luxurious and comfortable environments tailored to your lifestyle.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES_DATA.map((service, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ margin: "-100px" }}
                transition={{ 
                  duration: 0.6, 
                  delay: i * 0.1,
                  type: "spring",
                  stiffness: 100
                }}
                whileHover={{ y: -12, scale: 1.02 }}
                onClick={() => setSelectedService(service)}
                className="group bg-white border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-500 overflow-hidden cursor-pointer"
              >
                <div className="h-64 overflow-hidden relative">
                  <img 
                    src={service.img} 
                    alt={service.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      e.currentTarget.src = "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80"; // Fallback to hero-style image
                    }}
                  />
                  <div className="absolute inset-0 bg-brand-cyan/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <div className="p-8">
                  <h3 className="text-2xl mb-2 group-hover:text-brand-cyan transition-colors font-bold uppercase tracking-tight">{service.title}</h3>
                  <p className="text-slate-500 mb-6 text-sm leading-relaxed font-medium">{service.desc}</p>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedService(service);
                    }}
                    className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-brand-cyan group-hover:gap-4 transition-all"
                  >
                    Discover Details <ArrowRight size={14} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="projects" className="bg-slate-900 py-24 px-6 md:px-12 lg:px-24">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <div className="h-1 w-12 bg-brand-cyan mb-6" />
            <h2 className="text-4xl md:text-5xl text-white uppercase font-extrabold tracking-tight">Our Projects</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 md:grid-rows-2 gap-4 h-auto md:h-[800px]">
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="md:col-span-2 md:row-span-2 relative group overflow-hidden"
            >
              <img src={IMAGES.portfolio1} className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-1000" alt="Villa" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent p-10 flex flex-col justify-end">
                <span className="text-brand-cyan text-xs font-bold uppercase tracking-widest mb-2 opacity-0 group-hover:opacity-100 transition-all translate-y-4 group-hover:translate-y-0">Luxury Residential</span>
                <h4 className="text-3xl text-white font-bold">Ornate Villa Faridabad</h4>
              </div>
            </motion.div>
            
            <motion.div 
               whileHover={{ scale: 1.02 }}
              className="md:col-span-2 relative group overflow-hidden"
            >
              <img src={IMAGES.portfolio2} className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-1000" alt="Office" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent p-10 flex flex-col justify-end">
                <span className="text-brand-cyan text-xs font-bold uppercase tracking-widest mb-2 opacity-0 group-hover:opacity-100 transition-all translate-y-4 group-hover:translate-y-0">Commercial Space</span>
                <h4 className="text-2xl text-white font-bold">Modern Office Hub</h4>
              </div>
            </motion.div>

            <motion.div 
               whileHover={{ scale: 1.02 }}
              className="relative group overflow-hidden"
            >
              <img src={IMAGES.portfolio3} className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-1000" alt="Apt" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent p-6 flex flex-col justify-end">
                <h4 className="text-xl text-white font-bold">Elegant Apartment</h4>
              </div>
            </motion.div>

            <motion.div 
               whileHover={{ scale: 1.02 }}
              className="relative group overflow-hidden"
            >
              <img src={IMAGES.portfolio4} className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-1000" alt="Lounge" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent p-6 flex flex-col justify-end">
                <h4 className="text-xl text-white font-bold">Premium Kitchen</h4>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="section-padding bg-white">
        <div className="max-w-7xl mx-auto text-center mb-20">
          <h2 className="text-4xl md:text-5xl mb-4 font-extrabold uppercase tracking-tight text-slate-900">Our Process</h2>
          <p className="text-slate-500 max-w-2xl mx-auto font-medium italic">Our structured approach ensures perfection at every stage of your project.</p>
        </div>

        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-8 relative">
          {[
            { step: "01", title: "First Meet", desc: "Initial consultation and requirement gathering." },
            { step: "02", title: "Design Concept", desc: "Planning the fundamental look and flow." },
            { step: "03", title: "3D Visualization", desc: "Detailed 3D renders of your future space." },
            { step: "04", title: "Production", desc: "Sourcing materials and precision manufacturing." },
            { step: "05", title: "Quality Control", desc: "Rigorous inspection of every detail." },
            { step: "06", title: "Handover", desc: "Final installation and project completion." }
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="flex flex-col items-center group text-center"
            >
              <div className="w-14 h-14 bg-brand-sand border-2 border-slate-100 text-brand-cyan rounded-full flex items-center justify-center font-black mb-6 group-hover:bg-brand-cyan group-hover:text-white group-hover:border-brand-cyan group-hover:scale-110 transition-all duration-300 shadow-sm">
                {item.step}
              </div>
              <h4 className="text-sm font-extrabold uppercase tracking-widest mb-3 text-slate-800">{item.title}</h4>
              <p className="text-[11px] text-slate-500 leading-relaxed font-medium uppercase tracking-wider">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-brand-teal py-20 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-12 text-center text-white/90">
          {[
            { num: "500+", label: "PROJECTS DELIVERED" },
            { num: "3 YR", label: "WARRANTY PERIOD" },
            { num: "100%", label: "CLIENT SATISFACTION" },
            { num: "15+", label: "YEARS OF HERITAGE" }
          ].map((stat, i) => (
            <div key={i} className="space-y-2">
              <h3 className="text-3xl md:text-5xl font-bold">{stat.num}</h3>
              <p className="text-[10px] md:text-xs font-bold tracking-[0.2em] text-white/60">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="section-padding overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl mb-16 text-center italic">Voices of Satisfaction</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {[
              { 
                name: "Ananya Sharma", 
                role: "VILLA OWNER",
                text: "The way they balanced luxury with functional comfort is incredible. My living room feels like a page from a design magazine." 
              },
              { 
                name: "Vikram Malhotra", 
                role: "CORPORATE DIRECTOR",
                text: "Professional, transparent, and absolutely precise. The execution phase was smooth and the results exceeded expectations." 
              },
              { 
                name: "Priya Reddy", 
                role: "APARTMENT OWNER",
                text: "Their focus on editorial minimalism completely transformed my small apartment into a spacious-feeling sanctuary." 
              }
            ].map((t, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-12 border border-slate-100 shadow-sm relative group"
              >
                <Quote className="absolute top-8 right-8 text-brand-sand w-16 h-16 transition-colors group-hover:text-brand-cyan/10" />
                <div className="flex gap-1 text-brand-orange mb-6">
                  {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
                </div>
                <p className="text-lg italic text-slate-700 leading-relaxed mb-8 relative z-10">"{t.text}"</p>
                <div>
                  <h5 className="font-bold text-slate-900 tracking-wide">{t.name}</h5>
                  <p className="text-[10px] font-bold text-brand-cyan tracking-widest uppercase">{t.role}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section-padding bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl mb-4 font-extrabold uppercase tracking-tight text-slate-900">FAQ</h2>
            <p className="text-slate-500 font-medium italic">Common queries about our design process and services.</p>
          </div>

          <div className="space-y-4">
            {[
              {
                question: "What areas do you provide interior design services in?",
                answer: "We primarily serve Faridabad, Delhi, and the wider NCR region, transforming residential and commercial spaces with our expert design team."
              },
              {
                question: "Do you offer free design consultations?",
                answer: "Yes! Your first meeting with our design experts is complimentary. We discuss your vision, spatial needs, and budget to provide a preliminary roadmap."
              },
              {
                question: "What is the typical timeline for an interior project?",
                answer: "Timelines vary based on scope. A full home interior typically takes 45-75 days, while modular kitchen installations are often completed within 30-45 days."
              },
              {
                question: "Does LA Interiors provide any warranty on the work?",
                answer: "Absolutely. We stand behind our craftsmanship with an exclusive 3-year warranty on all our custom modular interiors and furniture."
              },
              {
                question: "Can I get a 3D visualization before the work starts?",
                answer: "Yes, 3D visualization is a core part of our process. We provide high-quality renders so you can see exactly how your space will look before production begins."
              }
            ].map((faq, i) => (
              <div key={i} className="border border-slate-100 overflow-hidden">
                <button 
                  onClick={() => setOpenFaqIndex(openFaqIndex === i ? null : i)}
                  className="w-full flex items-center justify-between p-6 text-left hover:bg-slate-50 transition-colors"
                >
                  <span className="font-bold text-slate-800 uppercase tracking-tight text-sm md:text-base">{faq.question}</span>
                  <motion.div
                    animate={{ rotate: openFaqIndex === i ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <ChevronDown size={20} className={openFaqIndex === i ? "text-brand-cyan" : "text-slate-400"} />
                  </motion.div>
                </button>
                <AnimatePresence>
                  {openFaqIndex === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: "easeInOut" }}
                    >
                      <div className="px-6 pb-6 text-slate-500 text-sm md:text-base font-medium leading-relaxed border-t border-slate-50 pt-4">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="about" className="section-padding bg-slate-50">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-24 items-start">
          <div className="space-y-12">
            <div>
              <div className="h-1 w-12 bg-brand-cyan mb-6" />
              <h2 className="text-4xl md:text-5xl mb-6 uppercase font-extrabold tracking-tight">Connect With Us</h2>
              <p className="text-slate-500 text-lg leading-relaxed font-medium">
                Visit our studio or drop us a message to start your interior journey. Our design consultants are ready to bring your vision to life.
              </p>
            </div>

            <div className="grid gap-8">
              {[
                { 
                  icon: <MapPin className="text-brand-cyan shrink-0" />, 
                  text: (
                    <span className="leading-relaxed">
                      <strong>LA Interiors</strong><br />
                      <span className="text-xs text-slate-400">( A Unit of Ornate Interiors India Pvt Ltd )</span><br />
                      BH-715/716, 81 High Street, Sector – 81,<br />
                      Greater Faridabad, Haryana – 121002
                    </span>
                  )
                },
                { icon: <Phone className="text-brand-cyan shrink-0" />, text: "+91 9873280202" },
                { icon: <Mail className="text-brand-cyan shrink-0" />, text: "info@lainteriors.in" }
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-4 p-4 hover:bg-white hover:shadow-md transition-all group">
                  <div className="group-hover:scale-110 transition-transform">{item.icon}</div>
                  <div className="font-medium text-slate-700 text-sm md:text-base">{item.text}</div>
                </div>
              ))}
            </div>

            {/* Newsletter */}
            <div className="pt-8 border-t border-slate-200">
              <h4 className="text-xs font-bold tracking-widest uppercase mb-6 text-slate-400">Newsletter</h4>
              <p className="text-sm text-slate-500 mb-6">Get weekly interior inspiration and design tips.</p>
              <div className="flex max-w-sm border-b border-slate-300 pb-2">
                <input 
                  type="email" 
                  placeholder="EMAIL ADDRESS" 
                  className="bg-transparent border-none focus:ring-0 text-sm w-full placeholder:text-slate-300"
                />
                <button className="text-brand-cyan"><ArrowRight size={20} /></button>
              </div>
            </div>
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            whileInView={{ opacity: 1, scale: 1 }}
            className="bg-white p-10 md:p-16 shadow-2xl border-t-8 border-brand-orange"
          >
            <h3 className="text-3xl mb-8">Personal Estimate</h3>
            <form onSubmit={handleEnquiry} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">Full Name</label>
                  <input 
                    type="text" 
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                    className="w-full bg-transparent border-0 border-b border-slate-200 p-2 focus:ring-0 focus:border-brand-cyan transition-all" 
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">Phone Number</label>
                  <input 
                    type="tel" 
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    className="w-full bg-transparent border-0 border-b border-slate-200 p-2 focus:ring-0 focus:border-brand-cyan transition-all" 
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">Project Type</label>
                <select 
                  value={formData.projectType}
                  onChange={(e) => setFormData({...formData, projectType: e.target.value})}
                  className="w-full bg-transparent border-0 border-b border-slate-200 p-2 focus:ring-0 focus:border-brand-cyan transition-all appearance-none cursor-pointer font-bold"
                >
                  <option>Full Home Design</option>
                  <option>Residential Interior</option>
                  <option>Office Interior</option>
                  <option>Kitchen Interior</option>
                  <option>Bedroom Interior</option>
                  <option>Living Room Design</option>
                  <option>Bathroom Interior</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">Brief Message</label>
                <textarea 
                  rows={3} 
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  className="w-full bg-transparent border-0 border-b border-slate-200 p-2 focus:ring-0 focus:border-brand-cyan transition-all resize-none"
                ></textarea>
              </div>
              {showSuccess && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-brand-sand p-6 border-l-4 border-brand-teal mb-6 space-y-3"
                >
                  <p className="text-brand-teal text-sm font-bold">Enquiry Draft Prepared!</p>
                  <p className="text-slate-600 text-xs font-medium">If your Gmail browser tab didn't open automatically, please click the button below.</p>
                  <a 
                    href={`https://mail.google.com/mail/?view=cm&fs=1&to=info@lainteriors.in&su=${encodeURIComponent("Enquiry for Interior Design Services")}&body=${encodeURIComponent(
`Dear LA Interiors Team,

I am interested in your ${formData.projectType || 'Interior Design'} services.

My Details:
Name: ${formData.fullName}
Phone: ${formData.phone}
Message: ${formData.message}

Regards,
${formData.fullName}`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-white bg-brand-teal px-6 py-3 text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-colors"
                    onClick={() => {
                      setShowSuccess(false);
                      setFormData({ fullName: "", phone: "", projectType: "Full Home Design", message: "" });
                    }}
                  >
                    Open Gmail Now <ArrowUpRight size={14} />
                  </a>
                </motion.div>
              )}

              <motion.button 
                whileHover={{ scale: isSubmitting ? 1 : 1.01 }}
                whileTap={{ scale: isSubmitting ? 1 : 0.99 }}
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-5 font-bold transition-all shadow-xl ${
                  isSubmitting 
                    ? "bg-slate-200 text-slate-400 cursor-not-allowed shadow-none" 
                    : "bg-brand-cyan text-white hover:bg-brand-teal hover:shadow-brand-cyan/20"
                }`}
              >
                {isSubmitting ? "OPENING EMAIL..." : "SEND ENQUIRY"}
              </motion.button>
            </form>
          </motion.div>
        </div>
      </section>

        </motion.div>
        ) : (
          <motion.div
            key="detail"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            className="min-h-screen pt-24 pb-20 px-6"
          >
            <div className="max-w-5xl mx-auto">
              <button 
                onClick={() => setSelectedService(null)}
                className="flex items-center gap-2 text-brand-cyan font-bold uppercase tracking-widest text-xs mb-12 hover:gap-4 transition-all"
              >
                <ChevronLeft size={16} /> Back to Services
              </button>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
                <motion.div
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="space-y-8"
                >
                  <div className="space-y-4">
                    <span className="text-brand-orange font-bold uppercase tracking-[0.3em] text-[10px]">Interior Category</span>
                    <h1 className="text-5xl md:text-7xl font-bold uppercase tracking-tighter leading-none">{selectedService.title}</h1>
                  </div>
                  
                  <p className="text-slate-600 text-lg leading-relaxed font-medium">
                    {selectedService.details}
                  </p>

                  <div className="grid grid-cols-2 gap-6 pt-6">
                    {selectedService.features.map((feature, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <div className="w-1.5 h-1.5 bg-brand-cyan rounded-full" />
                        <span className="text-sm font-bold text-slate-800 uppercase tracking-tight">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-10 flex flex-wrap gap-4">
                    <button 
                      onClick={() => scrollToContactWithService(selectedService.title)}
                      className="bg-brand-cyan text-white px-10 py-5 font-bold hover:bg-brand-teal transition-all shadow-xl uppercase tracking-widest text-sm"
                    >
                      Get Estimate for this
                    </button>
                    <a 
                      href="https://wa.me/919873280202"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-white text-slate-900 border border-slate-200 px-10 py-5 font-bold hover:bg-slate-50 transition-all uppercase tracking-widest text-sm"
                    >
                      Chat with Expert
                    </a>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3 }}
                  className="relative aspect-square md:aspect-[4/5] rounded-sm overflow-hidden shadow-2xl"
                >
                  <img 
                    src={selectedService.img} 
                    alt={selectedService.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none" />
                </motion.div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-white/5 py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-16">
            <div className="space-y-8">
              <div 
                onClick={() => {
                  setSelectedService(null);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="flex items-center gap-2 cursor-pointer"
              >
                <img 
                  src={IMAGES.logo} 
                  alt="LA Interiors" 
                  className="h-16 md:h-20 w-auto"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.parentElement?.querySelector('.footer-logo-fallback')?.classList.remove('hidden');
                  }}
                  referrerPolicy="no-referrer"
                />
                <div className="footer-logo-fallback hidden flex items-center gap-2">
                  <div className="w-8 h-8 bg-brand-cyan flex items-center justify-center text-white font-serif font-bold text-lg text-white">LA</div>
                  <span className="font-serif text-xl font-bold tracking-tight text-white italic">INTERIORS</span>
                </div>
              </div>
              <div className="space-y-4 max-w-xl">
                <p className="text-white/80 text-sm leading-relaxed font-bold italic">
                  LA Interiors is one stop for top quality, assistance and service of interior designing based in Faridabad, Haryana.
                </p>
                <p className="text-white/40 text-sm leading-relaxed font-medium">
                  Our services are considered as design wonders. Started with the passion of making the perfect reality for everyone, on a small scale has now developed into a brand and a name of trust in the market.
                </p>
              </div>
            </div>

            <div className="flex flex-col items-start lg:items-end justify-between gap-8">
              <div className="flex gap-10">
                {[
                  { Icon: Instagram, href: "https://www.instagram.com/lainteriors98/" },
                  { Icon: Facebook, href: "https://www.facebook.com/lainteriors.in" },
                  { Icon: Youtube, href: "https://www.youtube.com/channel/UCTqGV-omcfSGK10i5YP37ng" }
                ].map((social, i) => (
                  <a 
                    key={i} 
                    href={social.href} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-white/40 hover:text-brand-cyan transition-all hover:scale-110"
                  >
                    <social.Icon size={24} />
                  </a>
                ))}
              </div>
              <div className="text-left lg:text-right">
                <p className="text-white/20 text-[10px] tracking-[0.2em] font-bold uppercase mb-2">Designed for Excellence</p>
                <p className="text-white/10 text-[10px] tracking-[0.2em] font-medium uppercase">
                  © 2024 LA Interiors. All Rights Reserved.
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating CTA */}
      <motion.a 
        href="https://wa.me/919873280202?text=Hi!%20I%20visited%20your%20website%20and%20I%27m%20interested%20in%20your%20interior%20design%20services.%20Can%20we%20connect?"
        target="_blank"
        rel="noopener noreferrer"
        whileHover={{ scale: 1.05, y: -5 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-6 right-6 md:bottom-8 md:right-8 bg-brand-orange text-white px-6 md:px-8 py-3 md:py-4 font-bold shadow-2xl z-[60] flex items-center gap-3 group overflow-hidden rounded-sm"
      >
        <span className="relative z-10 text-xs md:text-sm tracking-widest">CHAT WITH EXPERT</span>
        <div className="absolute inset-0 bg-brand-teal translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
      </motion.a>
    </div>
  );
}
